const sdk = require("microsoft-cognitiveservices-speech-sdk");
const fs = require("fs");
const { spawn } = require("child_process");

const subscriptionKey = "c1ef651e990d4e9e84849600ad63b3bc";
const serviceRegion = "brazilsouth";
const mp3FilePath = "audio.mp3"; // Ruta al archivo MP3
const wavFilePath = "output6.wav"; // Ruta al archivo WAV convertido
const visemesFilePath = "visemes.json"; // Nombre del archivo JSON para guardar los visemes

async function convertMP3ToWAV() {
    return new Promise((resolve, reject) => {
        // Comando ffmpeg para convertir MP3 a WAV
        const ffmpeg = spawn("ffmpeg", [
            "-i", mp3FilePath,
            "-acodec", "pcm_s16le",
            "-ar", "16000",
            wavFilePath
        ]);

        // Capturar mensajes de stdout
        ffmpeg.stdout.on("data", data => {
            console.log(`stdout: ${data}`);
        });

        // Capturar mensajes de stderr
        ffmpeg.stderr.on("data", data => {
            console.error(`stderr: ${data}`);
        });

        // Capturar cierre del proceso
        ffmpeg.on("close", code => {
            if (code === 0) {
                console.log("MP3 to WAV conversion succeeded.");
                resolve();
            } else {
                reject(`MP3 to WAV conversion failed with code ${code}`);
            }
        });

        // Capturar error del proceso
        ffmpeg.on("error", err => {
            console.error("Failed to spawn ffmpeg", err);
            reject(err);
        });
    });
}

async function extractVisemes() {
    try {
        // Convertir MP3 a WAV
        await convertMP3ToWAV();

        // Crear un stream de lectura del archivo WAV
        const wavStream = fs.createReadStream(wavFilePath);

        // Crear el objeto AudioConfig desde el stream
        const audioConfig = sdk.AudioConfig.fromStreamInput(wavStream);

        // Configurar la suscripción al evento visemeReceived
        const synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);
        const visemes = [];

        synthesizer.visemeReceived = function (s, e) {
            console.log(`(Viseme) Audio offset: ${e.audioOffset / 10000}ms. Viseme ID: ${e.visemeId}`);
            const animation = e.animation;
            console.log(animation);

            visemes.push({
                audioOffset: e.audioOffset / 10000,
                visemeId: e.visemeId,
                animation: e.animation
            });
        };

        await new Promise((resolve, reject) => {
            synthesizer.speakTextAsync(
                "", // Texto vacío, solo necesitamos visemes
                result => {
                    console.log(`Viseme extraction succeeded from ${wavFilePath}`);
                    synthesizer.close();
                    resolve();
                },
                error => {
                    console.error(`Viseme extraction failed: ${error}`);
                    synthesizer.close();
                    reject(error);
                });
        });

        // Guardar visemes en un archivo JSON
        fs.writeFileSync(visemesFilePath, JSON.stringify(visemes, null, 2));
        console.log(`Visemes saved to ${visemesFilePath}`);

    } catch (err) {
        console.error(`Viseme extraction failed: ${err}`);
    }
}

async function main() {
    try {
        console.log(`Start viseme extraction from ${mp3FilePath}`);
        await extractVisemes();
    } catch (error) {
        console.error(error);
    }
}

main();
