const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sdk = require('microsoft-cognitiveservices-speech-sdk');
const fs = require('fs');
const path = require('path');

const subscriptionKey = 'c1ef651e990d4e9e84849600ad63b3bc';
const serviceRegion = 'brazilsouth';
const audioFilePath = 'output.wav'; // Nombre del archivo de salida (audio generado)
const visemesFilePath = 'visemes.json'; // Nombre del archivo JSON para guardar los visemes

const app = express();
app.use(bodyParser.json());
app.use(cors());

async function synthesizeSpeechAndVisemes(textToSpeak) {
    const audioConfig = sdk.AudioConfig.fromAudioFileOutput(audioFilePath);
    const speechConfig = sdk.SpeechConfig.fromSubscription(subscriptionKey, serviceRegion);

    // Configura la voz en español de Ecuador
    speechConfig.speechSynthesisLanguage = 'es-EC';
    speechConfig.speechSynthesisVoiceName = 'es-EC-AndreaNeural'; // Puedes cambiar el nombre de la voz según las disponibles

    const synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);

    // Arreglo para almacenar los visemes
    const visemes = [];

    // Subscripción al evento visemeReceived
    synthesizer.visemeReceived = function (s, e) {
        console.log(`(Viseme) Audio offset: ${e.audioOffset / 10000}ms. Viseme ID: ${e.visemeId}`);
        const animation = e.animation;
        console.log(animation); // Imprimir la animación en consola

        // Agregar viseme al arreglo
        visemes.push({
            audioOffset: e.audioOffset / 10000,
            visemeId: e.visemeId,
            animation: e.animation
        });
    };

    return new Promise((resolve, reject) => {
        synthesizer.speakTextAsync(textToSpeak,
            result => {
                console.log(`Speech synthesis succeeded. Audio file saved to ${audioFilePath}`);
                synthesizer.close();

                // Escribir visemes en un archivo JSON
                fs.writeFileSync(visemesFilePath, JSON.stringify(visemes, null, 2));
                console.log(`Visemes saved to ${visemesFilePath}`);
                //visemes = [];

                resolve();
            },
            error => {
                console.error(`Speech synthesis failed: ${error}`);
                synthesizer.close();
                reject(error);
            });
    });
}

app.post('/synthesize', async (req, res) => {
    const { text } = req.body;

    try {
        await synthesizeSpeechAndVisemes(text);
        res.json({ audioFilePath, visemesFilePath });
    } catch (error) {
        res.status(500).send(error.toString());
    }
});

app.get('/audio', (req, res) => {
    res.sendFile(path.resolve(__dirname, audioFilePath));
});

app.get('/visemes', (req, res) => {
    res.sendFile(path.resolve(__dirname, visemesFilePath));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
