// server.js

const express = require('express');
const axios = require('axios');
const { OpenAI } = require('openai');
require('dotenv').config();

const app = express();
const port = 3000;

const openai = new OpenAI({
    apiKey: process.env['OPENAI_API_KEY'],
});

// Middleware para permitir CORS (opcional, dependiendo de tus necesidades)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

// Middleware para parsear JSON
app.use(express.json());

// Ruta para recibir peticiones POST desde Angular
app.post('/chat', async (req, res) => {
  const { prompt } = req.body;
  try {
    const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
            {
                role: "system",
                content: "You are a helpful assistant."
            },
            {
                role: "user",
                content: prompt
            }
        ]
    });

    res.json({ text: response.choices[0].message.content });
  } catch (error) {
    console.error("Error en la solicitud a OpenAI:", error);
    res.status(500).json({ error: 'Error en la solicitud a OpenAI' });
  }
});

app.listen(port, () => {
  console.log(`Servidor de proxy para OpenAI escuchando en http://localhost:${port}`);
});
