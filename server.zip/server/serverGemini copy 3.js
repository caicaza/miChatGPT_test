const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const bodyParser = require('body-parser');
const cors = require('cors');
const speech = require('@google-cloud/speech');
const textToSpeech = require('@google-cloud/text-to-speech');
const fs = require('fs');
const util = require('util');
require('dotenv').config();


const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json({ limit: '50mb' })); // Aumenta el límite aquí
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true })); // Aumenta el límite aquí

const genAI = new GoogleGenerativeAI(process.env['GOOGLE_API_KEY']);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

 const chat = model.startChat({
    history: [
      {
        role: "user",
        parts: [{
            text: "Pretende que eres un cliente que quiere comprar unos audífonos"}]
        },
      {
        role: "model",
        parts: [{
            text:"Buenos días quiero comprar unos audífonos"}],
      },
    ],
    generationConfig: {
      maxOutputTokens: 100,
    },
  }); 

/*   const chat = model.startChat({
    history: [
      {
        role: "user",
        parts: [{
            text: "Eres un asistente virtual"}]
        },
      
    ],
    generationConfig: {
      maxOutputTokens: 100,
    },
  }); */

// Ruta para manejar los mensajes del chatGemini
app.post('/chatGemini', async (req, res) => {
  try {
    const { message } = req.body;
    const result = await chat.sendMessage(message + " responde en menos de 20 palabras. Recuerda que eres un cliente. No usar emojis");
    const reply = await result.response.text();
    res.json({ reply });
  } catch (error) {
    console.error('Error communicating with Gemini API:', error);
    res.status(500).json({ error: 'Error communicating with Gemini API' });
  }
});

const speechClient = new speech.SpeechClient();
const ttsClient = new textToSpeech.TextToSpeechClient();

// Ruta para transcribir audio
app.post('/transcribeGemini', async (req, res) => {
  const { audioContent } = req.body;

  if (!audioContent) {
    console.error('No audio content found in request');
    return res.status(400).json({ error: 'No audio content found in request' });
  }

  console.log('Received audio content:', audioContent.slice(0, 100) + '...'); // Log the beginning of the audio content

  const audio = {
    content: audioContent
  };
  const config = {
    encoding: 'FLINEAR16',
    languageCode: "es-EC",
  };
  const request = {
    audio: audio,
    config: config,
  };

  try {
    const [response] = await speechClient.recognize(request);
    console.log('API response:', response); // Log the raw API response

    if (!response.results || response.results.length === 0) {
      console.log('No transcription results found');
      return res.status(200).json({ transcription: '' });
    }

    const transcription = response.results.map(result => result.alternatives[0].transcript).join('\n');
    //console.log('response:', response);
    console.log('Transcription:', transcription);
    res.json({ transcription });
  } catch (error) {
    console.error('Error transcribing audio:', error);
    res.status(500).json({ error: 'Error transcribing audio' });
  }
});


// Ruta para convertir texto a voz
app.post('/textToSpeechGemini', async (req, res) => {
  const { text } = req.body;
  const request = {
    input: { text: text },
    voice: { languageCode: 'es-US',  name: "es-US-Neural2-A" },
    audioConfig: { audioEncoding: 'MP3' },
  };

  try {
    const [response] = await ttsClient.synthesizeSpeech(request);
    const audioContent = response.audioContent.toString('base64');
    res.json({ audioContent });
  } catch (error) {
    console.error('Error synthesizing text to speech:', error);
    res.status(500).json({ error: 'Error synthesizing text to speech' });
  }
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
