// server.js
//Server funcional analiza imagen, responde con voz y texto, analiza tu voz
const express = require('express');
const axios = require('axios');
const { OpenAI } = require('openai');
require('dotenv').config();

//Para os archivos
const multer = require('multer');
const fs = require('fs');
const pdfParse = require('pdf-parse');
// Variable para almacenar el contenido del PDF en memoria
let pdfContent = '';

//Para el tts
const path = require('path');

//Para el speachtoText
const fileUpload = require('express-fileupload');

//Para analizar la imagen 
 const FormData = require('form-data');
const base64 = require('base-64');

const app = express();
const port = 3000;

const openai = new OpenAI({
    apiKey: process.env['OPENAI_API_KEY'],
});

// Configuración de multer para manejar la carga de archivos
const upload = multer({ dest: 'uploads/' });

// Configuración de multer para manejar la carga de archivos
 const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now());
  },
});

const uploadImage = multer({ storage: storage }); 


// Middleware para permitir CORS (opcional, dependiendo de tus necesidades)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

// Middleware para parsear JSON
app.use(express.json());

// Ruta para cargar el archivo
app.post('/upload', upload.single('file'), (req, res) => {
  const filePath = req.file.path;

  if (req.file.mimetype === 'application/pdf') {
    fs.readFile(filePath, (err, data) => {
      if (err) {
        console.error('Error al leer el archivo:', err);
        res.status(500).json({ error: 'Error al leer el archivo' });
        return;
      }

      pdfParse(data).then(pdfData => {
        // Guardar el contenido del archivo en la variable global
        pdfContent = pdfData.text;
        console.log(pdfContent);

        // Eliminar el archivo después de leerlo para no ocupar espacio innecesario
        fs.unlink(filePath, (err) => {
          if (err) {
            console.error('Error al eliminar el archivo:', err);
          }
        });

        res.status(200).json({ message: 'Archivo PDF cargado y leído correctamente' });
      }).catch(error => {
        console.error('Error al parsear el PDF:', error);
        res.status(500).json({ error: 'Error al parsear el PDF' });
      });
    });
  } else {
    console.error('El archivo no es un PDF.');
    fs.unlink(filePath, (err) => {
      if (err) {
        console.error('Error al eliminar el archivo:', err);
      }
    });
    res.status(400).json({ error: 'Solo se permiten archivos PDF' });
  }
});

// Ruta para recibir peticiones POST desde Angular
// Variable para almacenar el contexto de la conversación
let conversationContext = [
  {
    role: "system",
    content: "You are a helpful assistant."
  }
];

// Ruta para recibir peticiones POST desde Angular y generar respuesta TTS
app.post('/chat', async (req, res) => {
  const { prompt, voice = "alloy" } = req.body;
  const speechFile = path.resolve('./response.mp3');

  try {
    // Añadir el contenido del PDF al contexto solo si no se ha añadido antes
    if (pdfContent && !conversationContext.some(msg => msg.content === pdfContent)) {
      conversationContext.push({
        role: "system",
        content: pdfContent
      });
    }

    // Añadir el mensaje del usuario al contexto
    conversationContext.push({
      role: "user",
      content: prompt + " Responde en menos de 20 palabras"
    });

    const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: conversationContext
    });

    // Añadir la respuesta del asistente al contexto
    const assistantMessage = {
      role: "assistant",
      content: response.choices[0].message.content
    };
    conversationContext.push(assistantMessage);

    // Generar archivo de audio para la respuesta
    const mp3 = await openai.audio.speech.create({
      model: "tts-1",
      voice: voice,
      input: assistantMessage.content,
    });
   
    
    //respuesta
    const buffer = Buffer.from(await mp3.arrayBuffer());
    await fs.promises.writeFile(speechFile, buffer);

    const transcription = await openai.audio.transcriptions.create({
      file: fs.createReadStream(speechFile),
      model: "whisper-1",
      response_format: "verbose_json",
      timestamp_granularities: ["word"]
    });


    // Extraer texto y timestamps
    //const transcription = transcriptionResponse.data.text;
    const wordsWithTimestamps = transcription.words;
    //console.log(wordsWithTimestamps);

    const letterTimestamps =  asignarNumerosYTiempo(wordsWithTimestamps);
    //console.log(letterTimestamps);


    res.json({ text: assistantMessage.content, audio: `http://localhost:${port}/audio`, viseme: letterTimestamps  });
  } catch (error) {
    console.error("Error en la solicitud a OpenAI:", error);
    res.status(500).json({ error: 'Error en la solicitud a OpenAI' });
  }
});

// Ruta para servir el archivo de audio
app.get('/audio', (req, res) => {
  const speechFile = path.resolve('./response.mp3');
  res.sendFile(speechFile);
});

//speech-to-text
app.post('/speech-to-text', async (req, res) => {
  const { text } = req.body;
  try {
    const response = await openai.audio.transcriptions.create({
      file: fs.createReadStream('/path/to/file/audio.mp3'),
      model: 'whisper-1',
    });
    const audioBuffer = Buffer.from(response.data, 'binary');
    res.set('Content-Type', 'audio/mpeg');
    res.send(audioBuffer);
  } catch (error) {
    console.error('Error generating speech:', error);
    res.status(500).send('Error generating speech');
  }
});

//vision analizar imagen

app.post('/vision', uploadImage.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      res.status(400).json({ error: 'No se ha proporcionado ninguna imagen' });
      return;
    }

    const imageFile = req.file.path;

    // Procesar la imagen en OpenAI
    const response = await processImageInOpenAI(imageFile);
    res.json(response.choices[0].message.content);
  } catch (error) {
    console.error('Error al procesar la imagen:', error);
    res.status(500).json({ error: 'Error al procesar la imagen' });
  }
});

async function processImageInOpenAI(imageFile) {
  try {
    const base64_image = await encodeImage(imageFile);

    const headers = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${process.env['OPENAI_API_KEY']}`,
    };

    const payload = {
      model: 'gpt-4o',
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: 'Analiza y describe el cáracter de la persona de acuerdo a sus expresiones faciales y postura. También su emoción como felicidad, tristeza, ira, desinteres, etc. En menos de 20 palabras.' },
            { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${base64_image}` } },
          ],
        },
      ],
      max_tokens: 200,
    };

    const openaiResponse = await axios.post('https://api.openai.com/v1/chat/completions', payload, {
      headers,
    });

    // Añadir la respuesta del asistente al contexto    
    conversationContext.push(payload.messages[0]);

    return openaiResponse.data;
  } catch (error) {
    throw new Error('Error procesando imagen en OpenAI');
  }
}

function encodeImage(imagePath) {
  return new Promise((resolve, reject) => {
    fs.readFile(imagePath, (err, data) => {
      if (err) {
        reject(err);
      } else {
        const base64_image = Buffer.from(data).toString('base64');
        resolve(base64_image);
      }
    });
  });
}

//Para sacar los lips de los labios

function asignarNumerosYTiempo(transcripcion) {
  let letrasNumerosTiempo = [];

  for (let i = 0; i < transcripcion.length; i++) {
    let palabra = transcripcion[i];
    let tiempoTotal = palabra.end - palabra.start;
    let tiempoPorLetra = tiempoTotal / palabra.word.length;
    
    for (let j = 0; j < palabra.word.length; j++) {
      let letra = palabra.word[j];
      let visemeId = asignarNumeroALetra(letra);
      
      let tiempoInicio = palabra.start + j * tiempoPorLetra;
      
      let audioOffset=redondearNumero(tiempoInicio);
      
      
      letrasNumerosTiempo.push({ audioOffset, visemeId });
    }
  }

  return letrasNumerosTiempo;
}

// Función para asignar el número correspondiente a cada letra
function asignarNumeroALetra(letra) {
  const tabla = {
    '0': ['silencio'],
  '1': ['A', 'a', 'á'],
  '2': ['K', 'k'],
  '3': ['o', 'O', 'ó'],
  '4': ['e', 'E','é'],
  '5': ['d', 'D'],
  '6': ['j', 'i', 'J', 'I', 'í'],
  '7': ['ñ','Ñ'],
  '8': ['w',  'W', ],
  '9': ['u', 'U', 'ú', 'ü'],
  '10': ['h', 'H'],
  '11': ['y', 'Y'],
  '12': ['h', 'H'],
  '13': ['r', 'R'],
  '14': ['l', 'L'],
  '15': ['s', 'z', 'S', 'Z'],
  '16': ['ll', 'LL'],
  '17': ['f', 'v', 'F', 'V'],
  '18': ['d', 't', 'n', 'D', 'T', 'N'],
  '19': ['g', 'G'],
  '20': ['k', 'g', 'K', 'G'],
  '21': ['p', 'b', 'm', 'q', 'Q', 'P', 'B', 'M']
  };

  for (const numero in tabla) {
    if (tabla[numero].includes(letra.toLowerCase())) {
      return parseInt(numero);
    }
  }

  // Si la letra no está en la tabla, asignamos el número 0
  return 0;
}

function redondearNumero(numero) {
  const tiempoEnMs = parseFloat((numero * 1000).toFixed(3)); // Convertir segundos a milisegundos
  return tiempoEnMs;
}



//Puerto


app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});

