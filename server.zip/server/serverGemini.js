const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const bodyParser = require('body-parser');
const cors = require('cors');
const speech = require('@google-cloud/speech');
const textToSpeech = require('@google-cloud/text-to-speech');
const fs = require('fs');
const util = require('util');
require('dotenv').config();
const multer = require('multer');


const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json({ limit: '50mb' })); // Aumenta el límite aquí
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true })); // Aumenta el límite aquí

const genAI = new GoogleGenerativeAI(process.env['GOOGLE_API_KEY']);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

// Configuración de multer para manejar la carga de archivos
const upload = multer({ dest: 'uploads/' });

// Configuración de multer para manejar la carga de archivos
 const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now());
  },
});

const uploadImage = multer({ storage: storage }); 


 const chat = model.startChat({
    history: [
      {
        role: "user",
        parts: [{
            text: "Pretende que eres un cliente que quiere comprar unos audífonos"}]
        },
      {
        role: "model",
        parts: [{
            text:"Buenos días quiero comprar unos audífonos"}],
      },
    ],
    generationConfig: {
      maxOutputTokens: 500,
    },
  }); 

/*   const chat = model.startChat({
    history: [
      {
        role: "user",
        parts: [{
            text: "Eres un asistente virtual"}]
        },
      
    ],
    generationConfig: {
      maxOutputTokens: 100,
    },
  }); */

// Ruta para manejar los mensajes del chatGemini


app.post('/chatGemini', async (req, res) => {
  try {
    const { message } = req.body;
    const result = await chat.sendMessage(message + " responde en menos de 20 palabras. Recuerda que eres un cliente. No usar emojis");
    const reply = await result.response.text();
    res.json({ reply });
  } catch (error) {
    console.error('Error communicating with Gemini API:', error);
    res.status(500).json({ error: 'Error communicating with Gemini API' });
  }
});

const speechClient = new speech.SpeechClient();
const ttsClient = new textToSpeech.TextToSpeechClient();

// Ruta para transcribir audio
app.post('/transcribeGemini', async (req, res) => {
  const { audioContent } = req.body;

  if (!audioContent) {
    console.error('No audio content found in request');
    return res.status(400).json({ error: 'No audio content found in request' });
  }

  console.log('Received audio content:', audioContent.slice(0, 100) + '...'); // Log the beginning of the audio content

  const audio = {
    content: audioContent
  };
  const config = {
    encoding: 'FLINEAR16',
    languageCode: "es-EC",
  };
  const request = {
    audio: audio,
    config: config,
  };

  try {
    const [response] = await speechClient.recognize(request);
    console.log('API response:', response); // Log the raw API response

    if (!response.results || response.results.length === 0) {
      console.log('No transcription results found');
      return res.status(200).json({ transcription: '' });
    }

    const transcription = response.results.map(result => result.alternatives[0].transcript).join('\n');
    //console.log('response:', response);
    console.log('Transcription:', transcription);
    res.json({ transcription });
  } catch (error) {
    console.error('Error transcribing audio:', error);
    res.status(500).json({ error: 'Error transcribing audio' });
  }
});


// Ruta para convertir texto a voz
app.post('/textToSpeechGemini', async (req, res) => {
  const { text } = req.body;
  const request = {
    input: { text: text },
    voice: { languageCode: 'es-US',  name: "es-US-Neural2-A" },
    audioConfig: { audioEncoding: 'MP3' },
  };

  try {
    const [response] = await ttsClient.synthesizeSpeech(request);
    const audioContent = response.audioContent.toString('base64');
    const audioAnalisis = response.audioContent;
    // Save the audio content to a file
    const audioFileName = 'outputGemini.mp3';
    fs.writeFileSync(audioFileName, audioAnalisis, 'binary');

    // Prepare the request for speech-to-text
    const sttRequest = {
      config: {
          enableWordTimeOffsets: true,
          encoding: 'MP3',
          languageCode: 'es-US',
      },
      audio: { content: audioContent.toString('base64') },
  };
  const [operation] = await speechClient.longRunningRecognize(sttRequest);
  //Para sacar visemas pasamos de speech a text oara obtener tiempos de cada palabra
  const [respAnalisis] = await operation.promise();

   const wordTimeOffsets = respAnalisis.results.flatMap(result => 
    result.alternatives[0].words.map(wordInfo => ({
        word: wordInfo.word,
        start: wordInfo.startTime.seconds.low+(wordInfo.startTime.nanos / 1000000000),
        end: wordInfo.endTime.seconds.low+(wordInfo.endTime.nanos / 1000000000)
    }))
  ); 


  const letterTimestamps =  asignarNumerosYTiempo(wordTimeOffsets);
  //console.log(letterTimestamps);

    res.json({ audio: audioContent, viseme: letterTimestamps });
  } catch (error) {
    console.error('Error synthesizing text to speech:', error);
    res.status(500).json({ error: 'Error synthesizing text to speech' });
  }
});

//Para sacar los lips de los labios

function asignarNumerosYTiempo(transcripcion) {
  let letrasNumerosTiempo = [];

  for (let i = 0; i < transcripcion.length; i++) {
    let palabra = transcripcion[i];
    let tiempoTotal = parseFloat(palabra.end) - parseFloat(palabra.start);
    let tiempoPorLetra = tiempoTotal / palabra.word.length;
    
    for (let j = 0; j < palabra.word.length; j++) {
      // Solo procesar letras en posiciones impares (j es impar)
      if (j % 2 !== 0) continue;

      let letra = palabra.word[j];
      let visemeId = asignarNumeroALetra(letra);
      
      let tiempoInicio = parseFloat(palabra.start) + j * tiempoPorLetra;
      let audioOffset = tiempoInicio.toFixed(3);
      
      letrasNumerosTiempo.push({ audioOffset, visemeId });
      if (j==palabra.word.length-1) {
        
        visemeId = asignarNumeroALetra(',');
        letrasNumerosTiempo.push({ audioOffset, visemeId });
        
      }
    }
  }

  return letrasNumerosTiempo;
}

// Función para asignar el número correspondiente a cada letra
function asignarNumeroALetra(letra) {
  const tabla = {
    '0': ['silencio'],
  '1': ['A', 'a', 'á'],
  '2': ['K', 'k'],
  '3': ['o', 'O', 'ó'],
  '4': ['e', 'E','é'],
  '5': ['d', 'D'],
  '6': ['j', 'i', 'J', 'I', 'í'],
  '7': ['ñ','Ñ'],
  '8': ['w',  'W', ],
  '9': ['u', 'U', 'ú', 'ü'],
  '10': ['h', 'H'],
  '11': ['y', 'Y'],
  '12': ['h', 'H'],
  '13': ['r', 'R'],
  '14': ['l', 'L'],
  '15': ['s', 'z', 'S', 'Z'],
  '16': ['ll', 'LL'],
  '17': ['f', 'v', 'F', 'V'],
  '18': ['d', 't', 'n', 'D', 'T', 'N'],
  '19': ['g', 'G'],
  '20': ['k', 'g', 'K', 'G'],
  '21': ['p', 'b', 'm', 'q', 'Q', 'P', 'B', 'M']
  };

  for (const numero in tabla) {
    if (tabla[numero].includes(letra.toLowerCase())) {
      return parseInt(numero);
    }
  }

  // Si la letra no está en la tabla, asignamos el número 0
  return 0;
}

const imageResponses = [];


app.post('/processImageGemini',  upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      res.status(400).json({ error: 'No se ha proporcionado ninguna imagen' });
      return;
    }
    console.log("");
    const imageFile = req.file.path;
    console.log(imageFile);


    // Procesar la imagen en OpenAI
    const response = await processImageInGemini(imageFile);

    imageResponses.push(response);
    res.json(response);
  } catch (error) {
    console.error('Error al procesar la imagen:', error);
    res.status(500).json({ error: 'Error al procesar la imagen' });
  }
});

async function processImageInGemini(imageFile) {
  try {
    const base64_image = await encodeImage(imageFile);
    const prompt = "¿La persona de la imagen que tipo de actitud tiene? Indicame el cáracter y reacción facial. Contesta em español, menos de 50 palabras.";

    const image = {
      inlineData: {
        data: base64_image,
        mimeType: "image/jpeg",
      },
    };

    const result = await model.generateContent([prompt, image]);
  

    return result.response.text();
  } catch (error) {
    throw new Error('Error procesando imagen en OpenAI');
  }
}

function encodeImage(imagePath) {
  return new Promise((resolve, reject) => {
    fs.readFile(imagePath, (err, data) => {
      if (err) {
        reject(err);
      } else {
        const base64_image = Buffer.from(data).toString('base64');
        resolve(base64_image);
      }
    });
  });
}


//Actualizar chat
// Inicializar el historial del chat


app.post('/chatGeminiJsonResp', async (req, res) => {
  try {
    //const { message } = req.body;
    // Obtener el puntaje y la explicación de cada criterio del prompt
    const evaluation = {
      uso_tecnicas_marketing: {
        puntuacion: 0,
        explicacion: 0
      },
      profesionalismo: {
        puntuacion: "",
        explicacion: ""
      },
      caracter: {
        puntuacion: "",
        explicacion: ""
      },
      atencion_cliente: {
        puntuacion: "",
        explicacion: ""
      },
      conocimiento_producto: {
        puntuacion: "",
        explicacion: ""
      },
      reaccion_facial: {
        puntuacion: "",
        explicacion: ""
      },
      consejos_generales: ""
    };

    const descriptionsText = imageResponses.join('\n');


    // Combinar el prompt con la evaluación
    const promptIntern = `En base a estas descripciones del vendedor [`+descriptionsText+`] Evalua y genera JSON sobre la conversación anterior, califica al vendedor con estos parámetros con puntuaciones sobre 10: ${JSON.stringify(evaluation)}`;

    model.generationConfig={
      response_mime_type: "application/json",
     
    };

    const result = await chat.sendMessage(promptIntern);
    const reply = await result.response.text();
    console.log(reply);
    res.json({ reply });
  } catch (error) {
    console.error('Error communicating with Gemini API:', error);
    res.status(500).json({ error: 'Error communicating with Gemini API' });
  }
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
