
const sdk = require("microsoft-cognitiveservices-speech-sdk");
const fs = require("fs");

const subscriptionKey = "c1ef651e990d4e9e84849600ad63b3bc";
const serviceRegion = "brazilsouth";
const audioFilePath = "audio.wav"; // Nombre del archivo de salida (audio generado)
const textToSpeak = "Hola, estoy probando la síntesis de voz en Azure."; // Texto a sintetizar
const visemesFilePath = "visemes.json"; // Nombre del archivo JSON para guardar los visemes

async function synthesizeSpeechAndVisemes() {
    const pushStream = sdk.AudioInputStream.createPushStream();

    // Open the file and push it to the push stream.
    fs.createReadStream(audioFilePath).on('data', function(arrayBuffer) {
        pushStream.write(arrayBuffer);
    }).on('end', function() {
        pushStream.close();
    });


    const audioConfig = sdk.AudioConfig.fromAudioFileOutput(pushStream);
    const speechConfig = sdk.SpeechConfig.fromSubscription(subscriptionKey, serviceRegion);

    const synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);

    // Arreglo para almacenar los visemes
    const visemes = [];

    // Subscripción al evento visemeReceived
    synthesizer.visemeReceived = function (s, e) {
        console.log(`(Viseme) Audio offset: ${e.audioOffset / 10000}ms. Viseme ID: ${e.visemeId}`);
        // `Animation` es una cadena XML para SVG o una cadena JSON para formas blend
        const animation = e.animation;
        console.log(animation); // Imprimir la animación en consola

        // Agregar viseme al arreglo
        visemes.push({
            audioOffset: e.audioOffset / 10000,
            visemeId: e.visemeId,
            animation: e.animation
        });
    };

    try {
        await new Promise((resolve, reject) => {
            synthesizer.speakTextAsync(textToSpeak,
                result => {
                    console.log(`Speech synthesis succeeded. Audio file saved to ${audioFilePath}`);
                    synthesizer.close();
                    resolve();
                },
                error => {
                    console.error(`Speech synthesis failed: ${error}`);
                    synthesizer.close();
                    reject(error);
                });
        });

        // Escribir visemes en un archivo JSON
        fs.writeFileSync(visemesFilePath, JSON.stringify(visemes, null, 2));
        console.log(`Visemes saved to ${visemesFilePath}`);

    } catch (err) {
        console.error(`Speech synthesis and visemes failed: ${err}`);
    }
}

async function main() {
    try {
        console.log("Start speech synthesis and viseme detection");
        await synthesizeSpeechAndVisemes();
    } catch (error) {
        console.error(error);
    }
}

main();
