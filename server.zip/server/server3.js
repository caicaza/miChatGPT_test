const express = require('express');
require("dotenv").config();
const OpenAI = require('openai');


const app = express();
const port = 3000;

if (!process.env.OPENAI_API_KEY) {
  console.error('Falta la clave de API de OpenAI. Asegúrate de que el archivo .env está configurado correctamente.');
  process.exit(1); // Termina el proceso si falta la clave de API
} else {
  console.log('Clave de API de OpenAI cargada correctamente');
}

const openai = new OpenAI({
    apiKey: process.env['OPENAI_API_KEY'],
     //dangerouslyAllowBrowser: true,
});

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

app.use(express.json());

app.post('/chat', async (req, res) => {
  const { prompt } = req.body;
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
    });

    res.json({ text: response.choices[0].message.content.trim() });
  } catch (error) {
    console.error('Error en la solicitud a OpenAI:', error);
    res.status(500).json({ error: 'Error en la solicitud a OpenAI' });
  }
});

app.get('/test-openai', async (req, res) => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: 'Hola, ¿cómo estás?' }],
    });

    res.json({ success: true, data: response.choices[0].message.content.trim() });
  } catch (error) {
    console.error('Error en la prueba de conexión a OpenAI:', error);
    res.status(500).json({ success: false, error: 'Error en la prueba de conexión a OpenAI' });
  }
});

app.listen(port, () => {
  console.log(`Servidor de proxy para OpenAI escuchando en http://localhost:${port}`);
});
