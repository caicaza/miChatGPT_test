const { OpenAI } = require("openai");
require("dotenv").config();

 const OpenAIClient = new OpenAI({
    apiKey: process.env['OPENAI_API_KEY'],
  });


  async function getChatResponse() {
    try {
        const chatCompletion = await OpenAIClient.chat.completions.create({
            model: "gpt-4o",
            messages: [
                {
                    role: "system",
                    content: "You are a helpful assistant."
                },
                {
                    role: "user",
                    content: "Que es el marketing"
                }
            ]
        });

        console.log(chatCompletion.choices[0].message.content);
    } catch (error) {
        console.error("Error:", error);
    }
}
console.log("respuesta");
getChatResponse();