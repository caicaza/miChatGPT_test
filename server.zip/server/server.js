const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { Configuration, OpenAIApi } = require('openai');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

const configuration = new Configuration({
  apiKey: 'sk-proj-cUaQLaE4YJhzAu7BBBQTT3BlbkFJ3nQTRgI3AUVcKWGTZHJA', // Reemplaza con tu API key
});
const openai = new OpenAIApi(configuration);

app.post('/api/chat', async (req, res) => {
  const userMessage = req.body.message;
  try {
    const response = await openai.createChatCompletion({
      model: 'gpt-4o', // Modelo de GPT-4
      messages: [{ role: 'user', content: userMessage }],
      max_tokens: 150,
    });
    const botMessage = response.data.choices[0].message.content.trim();
    res.json({ message: botMessage });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Error en la respuesta del bot.' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
