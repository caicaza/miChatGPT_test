const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Habilitar CORS para todas las solicitudes
app.use(cors());

// Configurar el middleware para analizar los cuerpos de las solicitudes como JSON
app.use(bodyParser.json());

const genAI = new GoogleGenerativeAI(process.env['GOOGLE_API_KEY']);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

const chat = model.startChat({
    history: [
      {
        role: "user",
        parts: [{
            text: "Pretende que eres un cliente que quiere comprar unos audífonos"}]
        },
      
      {
        role: "model",
        parts: [{
            text:"Buenos días quiero comprar unos audífonos"}],
      },
    ],
    generationConfig: {
      maxOutputTokens: 100,
    },
  });

// Ruta para manejar los mensajes del chatGemini
app.post('/chatGemini', async (req, res) => {
  try {
    const { message } = req.body;    

    const result = await chat.sendMessage(message + "responde en menos de 20 palabras");
    const reply = await result.response.text();

    res.json({ reply });
  } catch (error) {
    console.error('Error communicating with Gemini API:', error);
    res.status(500).json({ error: 'Error communicating with Gemini API' });
  }
});

// Servir el archivo HTML estático para la interfaz de chatGemini
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
