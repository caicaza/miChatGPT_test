const sdk = require("microsoft-cognitiveservices-speech-sdk");
const fs = require("fs");

const subscriptionKey = "c1ef651e990d4e9e84849600ad63b3bc";
const serviceRegion = "brazilsouth";
const audioFilePath = "output.wav"; // Nombre del archivo de salida (audio generado)
const textToSpeak = "Hola, estoy probando la síntesis de voz en Azure."; // Texto a sintetizar

async function synthesizeSpeech() {
    const audioConfig = sdk.AudioConfig.fromAudioFileOutput(audioFilePath);
    const speechConfig = sdk.SpeechConfig.fromSubscription(subscriptionKey, serviceRegion);

    // Configura la voz en español de España
    speechConfig.speechSynthesisLanguage = "es-EC";
    speechConfig.speechSynthesisVoiceName = "es-EC-AndreaNeural"; // Puedes cambiar el nombre de la voz según las disponibles

    const synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);

    try {
        await synthesizer.speakTextAsync(
            textToSpeak,
            result => {
                console.log(`Speech synthesis succeeded. Audio file saved to ${audioFilePath}`);
                synthesizer.close();
            },
            error => {
                console.error(`Speech synthesis failed: ${error}`);
                synthesizer.close();
            });

    } catch (err) {
        console.error(`Speech synthesis failed: ${err}`);
    }
}

async function main() {
    try {
        console.log("Start speech synthesis");
        await synthesizeSpeech();
    } catch (error) {
        console.error(error);
    }
}

main();
