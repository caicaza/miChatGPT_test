const express = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const bodyParser = require('body-parser');
const cors = require('cors');
const speech = require('@google-cloud/speech');
const textToSpeech = require('@google-cloud/text-to-speech');
const fs = require('fs');
const util = require('util');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());

const genAI = new GoogleGenerativeAI(process.env['GOOGLE_API_KEY']);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

async function transcribeGemini (audioFile){
    console.log(audioFile);
    const speechClient = new speech.SpeechClient();
    const file = fs.readFileSync(audioFile);
    const audioBytes = file.toString('base64');
    //console.log(audioBytes);

    const audio = {
        content: audioBytes
    }
    const config = {
        encoding: 'FLINEAR16',
        
        languageCode: "en-US",
    }

    return new Promise((resolve,reject)=>{
        speechClient.recognize({
            audio: audio,
            config: config,
        }).then(data=>{
            resolve(data)        
        })
        .catch (error => {
            console.error('Error transcribing audio:', error);
          }) 
    })
}

(async()=>{
    const data = await transcribeGemini('carlos.wav');
    console.log(data);
    console.log(data[0].results[0].alternatives[0].transcript);
})()