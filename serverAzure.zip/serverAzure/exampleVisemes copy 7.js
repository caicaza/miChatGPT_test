const sdk = require("microsoft-cognitiveservices-speech-sdk");
const fs = require("fs");

const subscriptionKey = "c1ef651e990d4e9e84849600ad63b3bc";
const serviceRegion = "brazilsouth";
const audioFilePath = "output.wav"; // Ruta al archivo de entrada WAV
const visemesFilePath = "visemes.json"; // Nombre del archivo JSON para guardar los visemes


async function recognizeSpeech() {
    // Configuración del servicio de reconocimiento de voz
    const speechConfig = sdk.SpeechConfig.fromSubscription(subscriptionKey, serviceRegion);

    // Configuración del archivo de audio de entrada
    const audioConfig = sdk.AudioConfig.fromWavFileInput(fs.readFileSync(audioFilePath));

    // Crear un reconocedor de voz
    const recognizer = new sdk.SpeechRecognizer(speechConfig, audioConfig);

    // Iniciar el reconocimiento de voz
    recognizer.recognizeOnceAsync(result => {
        console.log(`Speech recognition result: ${result.text}`);
        recognizer.close();
    }, error => {
        console.error(`Speech recognition error: ${error}`);
        recognizer.close();
    });
}

async function main() {
    try {
        console.log(`Start speech recognition from ${audioFilePath}`);
        await recognizeSpeech();
    } catch (error) {
        console.error(error);
    }
}

main();
