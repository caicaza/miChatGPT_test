const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { Configuration, OpenAIApi } = require('openai');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

const openai = axios.create({
  baseURL: 'https://api.openai.com/v1',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer sk-proj-cUaQLaE4YJhzAu7BBBQTT3BlbkFJ3nQTRgI3AUVcKWGTZHJA',
  },
});

const upload = multer({ dest: 'uploads/' });

let assistantConfig = {
  name: '',
  instructions: '',
  context: ''
};

app.post('/api/upload-config', upload.single('file'), (req, res) => {
  const file = req.file;
  const filePath = path.join(__dirname, file.path);
  const { assistantName, instructions } = req.body;

  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ error: 'Error reading file' });
    }
    assistantConfig = {
      name: assistantName,
      instructions: instructions,
      context: data
    };
    fs.unlink(filePath, () => {}); // Delete the file after reading
    res.json({ message: 'Configuration saved' });
  });
});

app.post('/api/chat', async (req, res) => {
  const userMessage = req.body.message;

  const messages = [
    { role: 'system', content: `You are ${assistantConfig.name}. ${assistantConfig.instructions}` },
    { role: 'system', content: `Context: ${assistantConfig.context}` },
    { role: 'user', content: userMessage },
  ];

  try {
    const response = await openai.post('/engines/text-davinci-003/completions', {
      messages: messages,
      max_tokens: 150,
    }, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer sk-proj-cUaQLaE4YJhzAu7BBBQTT3BlbkFJ3nQTRgI3AUVcKWGTZHJA',
      },
    });
    const botMessage = response.data.choices[0].text.trim();
    res.json({ message: botMessage });
  } catch (error) {
    console.error('Error:', error.response ? error.response.data : error.message);
    res.status(500).json({ error: 'Error en la respuesta del bot.' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
