const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sdk = require('microsoft-cognitiveservices-speech-sdk');
const fs = require('fs');
const path = require('path');

const subscriptionKey = 'c1ef651e990d4e9e84849600ad63b3bc';
const serviceRegion = 'brazilsouth';
let audioIndex = 0; // Índice para el nombre del archivo de audio
let visemesIndex = 0; // Índice para el nombre del archivo JSON de visemes

const app = express();
app.use(bodyParser.json());
app.use(cors());

async function synthesizeSpeechAndVisemes(textToSpeak) {
    const currentAudioFilePath = `output${audioIndex}.wav`;
    const currentVisemesFilePath = `visemes${visemesIndex}.json`;

    const audioConfig = sdk.AudioConfig.fromAudioFileOutput(currentAudioFilePath);
    const speechConfig = sdk.SpeechConfig.fromSubscription(subscriptionKey, serviceRegion);

    // Configura la voz en español de Ecuador
    speechConfig.speechSynthesisLanguage = 'es-EC';
    speechConfig.speechSynthesisVoiceName = 'es-EC-AndreaNeural'; // Puedes cambiar el nombre de la voz según las disponibles

    const synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);

    // Arreglo para almacenar los visemes
    const visemes = [];

    // Subscripción al evento visemeReceived
    synthesizer.visemeReceived = function (s, e) {
        console.log(`(Viseme) Audio offset: ${e.audioOffset / 10000}ms. Viseme ID: ${e.visemeId}`);
        const animation = e.animation;
        console.log(animation); // Imprimir la animación en consola

        // Agregar viseme al arreglo
        visemes.push({
            audioOffset: e.audioOffset / 10000,
            visemeId: e.visemeId,
            animation: e.animation
        });
    };

    return new Promise((resolve, reject) => {
        synthesizer.speakTextAsync(textToSpeak,
            result => {
                console.log(`Speech synthesis succeeded. Audio file saved to ${currentAudioFilePath}`);
                synthesizer.close();

                // Escribir visemes en un archivo JSON
                fs.writeFileSync(currentVisemesFilePath, JSON.stringify(visemes, null, 2));
                console.log(`Visemes saved to ${currentVisemesFilePath}`);

                resolve({ audioFilePath: currentAudioFilePath, visemesFilePath: currentVisemesFilePath });
            },
            error => {
                console.error(`Speech synthesis failed: ${error}`);
                synthesizer.close();
                reject(error);
            });
    });
}

app.post('/synthesize', async (req, res) => {
    const { text } = req.body;

    try {
        const { audioFilePath, visemesFilePath } = await synthesizeSpeechAndVisemes(text);
        res.json({ audioFilePath, visemesFilePath });

        // Incrementar el índice para el próximo audio y visemes
        audioIndex++;
        visemesIndex++;
    } catch (error) {
        res.status(500).send(error.toString());
    }
});

app.get('/audio', (req, res) => {
    let audioFilePath;

    if (req.query.path) {
        audioFilePath = req.query.path;
    } else {
        audioFilePath = `output${audioIndex - 1}.wav`;
    }

    res.sendFile(path.resolve(__dirname, audioFilePath), err => {
        if (err) {
            console.error(`Error sending audio file: ${err}`);
            res.status(404).send('Audio file not found');
        }
    });
});


app.get('/visemes', (req, res) => {
    const visemesFilePath = req.query.path || `visemes${visemesIndex - 1}.json`;

    res.sendFile(path.resolve(__dirname, visemesFilePath), err => {
        if (err) {
            console.error(`Error sending visemes file: ${err}`);
            res.status(404).send('Visemes file not found');
        }
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
